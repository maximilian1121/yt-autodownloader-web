# Auto-generated bundled script for yt_autodownloader_web WINDOWS/OTHER
import app
